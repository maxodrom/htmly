## HTMLy Papermod

[Papermod](https://github.com/adityatelange/hugo-PaperMod/) theme ported to HTMLy

## Installations

 -  Upload and extract the zip file into themes directory.
 -  Activate it from HTMLy panel.
 
## Text Summary

For any posts collection pages, the summary taken from the post description.

## Frontpage profile mode

Set the `Front page displays` in `Config/Reading` to `Static page` and edit the default welcome message. Also enable the `/blog` url for best user experience.