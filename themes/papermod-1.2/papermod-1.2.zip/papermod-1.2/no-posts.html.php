<?php if (!defined('HTMLY')) die('HTMLy'); ?>
<article class="post-single">
	<header class="post-header">
		<h1 class="post-title entry-hint-parent">No post found!</h1>
	</header> 
	
</article>